The package contains the implementation of Yen's algorithm for top-k shortest paths in a directed weighted graph. 

Note that:
1. It's implemented in CPP. (The version is 2)
2. The source code is compiled under visual studio 2008 c/c++ compiler. 
3. Compared with previous versions, version 2 does not require Boost library any longer.
4. Main() function explains how to use the implentation. 